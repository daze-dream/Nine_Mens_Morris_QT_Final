var class_board_location =
[
    [ "BoardLocation", "class_board_location.html#ad0d852c84c0034bcf2c12334fe06e23b", null ]
];