var classchoice_dialog_tests =
[
    [ "choiceDialogTests", "classchoice_dialog_tests.html#a954835d117f2d0e0fea5576807afbe6a", null ],
    [ "flipCoin", "classchoice_dialog_tests.html#a11512f2c4f9b504fe6c02eb85338b29c", null ],
    [ "randomInteger", "classchoice_dialog_tests.html#a3cf4b1395cbc5a13b4b99f2b24721add", null ]
];