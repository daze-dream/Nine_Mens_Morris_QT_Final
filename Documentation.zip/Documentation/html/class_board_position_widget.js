var class_board_position_widget =
[
    [ "BoardPositionWidget", "class_board_position_widget.html#a1c4c5dfd2a8a23eea87e08b027d61cab", null ]
];