var class_main_window =
[
    [ "MainWindow", "class_main_window.html#a996c5a2b6f77944776856f08ec30858d", null ],
    [ "~MainWindow", "class_main_window.html#ae98d00a93bc118200eeef9f9bba1dba7", null ],
    [ "ui", "class_main_window.html#a35466a70ed47252a0191168126a352a5", null ]
];