var hierarchy =
[
    [ "Board", "class_board.html", [
      [ "BoardWidget", "class_board_widget.html", null ]
    ] ],
    [ "BoardLocation", "class_board_location.html", null ],
    [ "BoardPosition", "class_board_position.html", [
      [ "BoardPositionWidget", "class_board_position_widget.html", null ]
    ] ],
    [ "choiceDialogTests", "classchoice_dialog_tests.html", null ],
    [ "manualTests", "classmanual_tests.html", null ],
    [ "Player", "class_player.html", null ],
    [ "QDialog", null, [
      [ "choicesdialog", "classchoicesdialog.html", null ]
    ] ],
    [ "QMainWindow", null, [
      [ "MainWindow", "class_main_window.html", null ]
    ] ],
    [ "QPushButton", null, [
      [ "BoardPositionWidget", "class_board_position_widget.html", null ]
    ] ],
    [ "QWidget", null, [
      [ "BoardWidget", "class_board_widget.html", null ]
    ] ]
];