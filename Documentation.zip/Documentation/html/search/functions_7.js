var searchData=
[
  ['increasefreepieces_289',['increaseFreePieces',['../class_player.html#a09fe03fecc188c3c2fa88191a1f94e36',1,'Player']]],
  ['isitvalid_290',['isItValid',['../class_board_position.html#a8591b3774ddf2b545ee0bbbc10f6e2f7',1,'BoardPosition']]],
  ['ismill_291',['isMill',['../class_board.html#a8b22ca044627365a112aa92e7ea3b0d7',1,'Board']]],
  ['ispartofmill_292',['isPartofMill',['../class_board_position.html#ab40b6cdcbe6fec5202d557bdc767b3e9',1,'BoardPosition']]],
  ['isvalidlocation_293',['isValidLocation',['../class_board.html#ae73b361815b6bbd616cc86f78a7d9118',1,'Board']]]
];
