var searchData=
[
  ['addpiece_235',['addPiece',['../class_player.html#a386669de756e2066e5a6c1362e84367a',1,'Player']]],
  ['addplayers_236',['addPlayers',['../class_board.html#a5762c0bc251e129a99cc14fb54bf5d4d',1,'Board']]],
  ['aimove_237',['AIMove',['../class_board.html#a07db125c4e5a2fe5c950b52c8b1758ae',1,'Board']]],
  ['aimovewidget_238',['AIMoveWidget',['../class_board_widget.html#aafb07f333c2048a0b6b2e240abec4b6d',1,'BoardWidget']]],
  ['aipressed_239',['AIPressed',['../classchoicesdialog.html#a4309af3f6de6c1e5730a5921a3754824',1,'choicesdialog']]]
];
