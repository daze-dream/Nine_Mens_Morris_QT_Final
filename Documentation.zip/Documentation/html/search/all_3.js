var searchData=
[
  ['decreasefreepieces_43',['decreaseFreePieces',['../class_player.html#a4dcf8ef6d2199af53768057a20e9f622',1,'Player']]],
  ['displayboard_44',['displayBoard',['../class_board.html#a4d4b5f673cf95ad76097d918d865e7fa',1,'Board']]],
  ['doalltests_45',['doAllTests',['../classmanual_tests.html#a29d973147734f4cc12bce03874ae35c4',1,'manualTests']]],
  ['domovephase1_46',['doMovePhase1',['../class_board.html#ad62109efd876789b43e23adb6a01da42',1,'Board']]],
  ['domovephase2_47',['doMovePhase2',['../class_board.html#a08a2e0919f8c76c29fa7e977d4d2f6bd',1,'Board']]]
];
