var searchData=
[
  ['randominteger_304',['randomInteger',['../classchoice_dialog_tests.html#a3cf4b1395cbc5a13b4b99f2b24721add',1,'choiceDialogTests::randomInteger()'],['../classchoicesdialog.html#aed719fcb5a95d1531c9b540e2de67cc1',1,'choicesdialog::randomInteger()']]],
  ['removepiece_305',['removePiece',['../class_board.html#acbed7e639f8241f2b58978fd44e14df1',1,'Board']]],
  ['removestyle_306',['removeStyle',['../class_board_widget.html#aa2408c951b3104e1d3b3d7fc0cb5dad7',1,'BoardWidget']]],
  ['resetboard_307',['resetBoard',['../class_board.html#a7cef7a9ca499d64c71cb170d67f76ad0',1,'Board']]],
  ['resetboardgui_308',['resetBoardGUI',['../class_board_widget.html#ad15d570a551cd4734d9bbf8563b22bd9',1,'BoardWidget']]],
  ['restorefreepieces_309',['restoreFreePieces',['../class_player.html#ad76c5eb50074f68d58a167f878afecbb',1,'Player']]]
];
