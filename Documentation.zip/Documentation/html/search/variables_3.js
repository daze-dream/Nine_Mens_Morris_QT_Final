var searchData=
[
  ['flipcoinbutton_359',['flipCoinButton',['../classchoicesdialog.html#afd5b4797a932f3c67c17b9ce0acf1ac6',1,'choicesdialog']]],
  ['freepieces_360',['freePieces',['../class_player.html#ab472435d73f2db5cf864d4948f568c38',1,'Player']]]
];
