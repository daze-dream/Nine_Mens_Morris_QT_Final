var searchData=
[
  ['activemills_346',['activeMills',['../class_player.html#a7d724dc162d702ee3dfcd7d72ab3f551',1,'Player']]],
  ['asciioffset_347',['asciiOffset',['../class_board.html#ac33c354707fcea4d039093b098de5f0d',1,'Board']]]
];
