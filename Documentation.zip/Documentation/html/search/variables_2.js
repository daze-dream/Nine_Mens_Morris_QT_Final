var searchData=
[
  ['choicedisplay_351',['choiceDisplay',['../classchoicesdialog.html#ab3776e83090e2b2b48404945d6425dd5',1,'choicesdialog']]],
  ['choices_352',['choices',['../class_board_widget.html#ae2e253de619ba112d728598a51653b0d',1,'BoardWidget']]],
  ['columngoal_353',['columnGoal',['../class_board_widget.html#a04aad80cd2013da6b121b594969f724f',1,'BoardWidget']]],
  ['columnselected_354',['columnSelected',['../class_board_widget.html#afb9456c8df656a90ce1416bf2e1024c5',1,'BoardWidget']]],
  ['coord_355',['coord',['../class_board_position.html#a01d74e7ce4d959436c89267825cb98fa',1,'BoardPosition']]],
  ['currentgamephase_356',['currentGamePhase',['../class_board_widget.html#ac9901d1a4628c2d3e363c49e6b478628',1,'BoardWidget']]],
  ['currentplayer_357',['currentPlayer',['../class_board.html#a86b952cc745c2bd392f74434653457d3',1,'Board']]],
  ['currentplayerlabel_358',['currentPlayerLabel',['../class_board_widget.html#a1a20efd74c8d8676a5e9a953dc029928',1,'BoardWidget']]]
];
