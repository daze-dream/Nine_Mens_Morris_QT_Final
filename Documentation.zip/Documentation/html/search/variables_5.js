var searchData=
[
  ['isai_362',['isAI',['../class_player.html#ae9c8c98b632c602b1ab4c66d9eceeb41',1,'Player']]],
  ['isflight_363',['isFlight',['../class_player.html#a2ad1035a64541784c964eec73e500a90',1,'Player']]],
  ['isvalid_364',['isValid',['../class_board_position.html#ae247257e2394804d4c468dd4a84050dd',1,'BoardPosition']]]
];
