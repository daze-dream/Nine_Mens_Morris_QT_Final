var searchData=
[
  ['hoverstyle_287',['hoverStyle',['../class_board_widget.html#aeefe3ee9f9e00c5431bb82a237ae83d3',1,'BoardWidget']]],
  ['humanpressed_288',['humanPressed',['../classchoicesdialog.html#a3353b9594f913f82230a73c132e123bd',1,'choicesdialog']]]
];
