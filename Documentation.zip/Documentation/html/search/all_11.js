var searchData=
[
  ['ui_195',['Ui',['../namespace_ui.html',1,'Ui'],['../class_main_window.html#a35466a70ed47252a0191168126a352a5',1,'MainWindow::ui()']]],
  ['unittest_2ecpp_196',['unittest.cpp',['../unittest_8cpp.html',1,'']]],
  ['updatefreepieces_197',['updateFreePieces',['../class_player.html#a38e0d8b1ff8868dd18f42d4414796d99',1,'Player']]],
  ['updatestatuslist_198',['updateStatusList',['../class_board_widget.html#ab1a007a17b6d6ed4c6900ceb2619f04c',1,'BoardWidget']]]
];
