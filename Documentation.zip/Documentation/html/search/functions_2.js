var searchData=
[
  ['checkandchangestate_245',['checkAndChangeState',['../class_board.html#ae6f0a7dcc4013d58a659819a6ace7df0',1,'Board']]],
  ['checkifpartofmill_246',['checkIfPartOfMill',['../class_board_position.html#ae60f8725b73e6156ca797ca89a4d360b',1,'BoardPosition']]],
  ['choicedialogtests_247',['choiceDialogTests',['../classchoice_dialog_tests.html#a954835d117f2d0e0fea5576807afbe6a',1,'choiceDialogTests']]],
  ['choicemade_248',['choiceMade',['../classchoicesdialog.html#a245a1c9b0ae8f4b45a57718a7fc29b60',1,'choicesdialog']]],
  ['choicesdialog_249',['choicesdialog',['../classchoicesdialog.html#a44b31cfe685125e3f7026cbae3199f98',1,'choicesdialog']]],
  ['choiceselected_250',['choiceSelected',['../class_board_widget.html#a501bb9e2c0e5c76bf9013d11c3ee561c',1,'BoardWidget']]]
];
