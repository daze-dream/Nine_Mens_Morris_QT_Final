var searchData=
[
  ['locationdisp_96',['locationDisp',['../class_board_position.html#a588b2e03142ca6fa7611a2b6e2d0fb57',1,'BoardPosition']]],
  ['locationstatus_97',['locationStatus',['../class_board_position.html#a7065a538fd1f63d894da8640c64aba5e',1,'BoardPosition']]]
];
