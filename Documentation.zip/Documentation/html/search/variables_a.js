var searchData=
[
  ['randnum_388',['randNum',['../classchoicesdialog.html#acca0f1eb8c7aa8c1fc60db8380c867f5',1,'choicesdialog']]],
  ['reset_389',['reset',['../class_board_widget.html#aba7f827145259d05b7307fe6f56bde4b',1,'BoardWidget']]],
  ['rowgoal_390',['rowGoal',['../class_board_widget.html#a724d5c429cfd639d4b2367ab9138fc1e',1,'BoardWidget']]],
  ['rowselected_391',['rowSelected',['../class_board_widget.html#a950caacba9c1051f0597ef94ada61cd4',1,'BoardWidget']]],
  ['rules_392',['rules',['../class_board_widget.html#ac8ebc5de86ebe26850e5731fb8012a2a',1,'BoardWidget']]]
];
