var searchData=
[
  ['singleplayerbutton_393',['singleplayerButton',['../classchoicesdialog.html#a6b07e8f51bd269f6e5eeb309a0371d78',1,'choicesdialog']]],
  ['stablemillminus_394',['stableMillMinus',['../class_board.html#a4203e4a23d036d478c800f5a32c04f92',1,'Board']]],
  ['stablemills_395',['stableMills',['../class_player.html#acbf8269b2be3b544859c304b70924d8b',1,'Player']]],
  ['state_396',['state',['../class_board.html#a4a0c1a34f54457f26488031dfe18396b',1,'Board']]],
  ['statuslist_397',['statusList',['../class_board_widget.html#a84f293f2a562b6ee3701b4594679b532',1,'BoardWidget']]],
  ['surrender_398',['surrender',['../class_board_widget.html#a927fe3b3fa8f09bb48ed8a3250c56697',1,'BoardWidget']]]
];
