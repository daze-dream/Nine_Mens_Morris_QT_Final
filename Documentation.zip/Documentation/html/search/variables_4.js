var searchData=
[
  ['gameoverannounce_361',['gameoverAnnounce',['../class_board_widget.html#ab7076b168e936118c673f201cc405845',1,'BoardWidget']]]
];
