var searchData=
[
  ['phase1check_298',['phase1Check',['../class_board.html#a4f3552438eccb16e0d84aaac20a1e9a0',1,'Board']]],
  ['phase2_5f1check_299',['phase2_1Check',['../class_board.html#a0dbbf39aca22f0dac8bcb58c246e945e',1,'Board']]],
  ['phase2_5f2check_300',['phase2_2Check',['../class_board.html#a3377ee3ec082da0f1a6b620a50d15f57',1,'Board']]],
  ['player_301',['Player',['../class_player.html#affe0cc3cb714f6deb4e62f0c0d3f1fd8',1,'Player::Player()'],['../class_player.html#a9c6acd3dc58d5e3b74ca13e8ec3d970c',1,'Player::Player(int id, bool isAI)']]],
  ['playersleavethenest_302',['playersLeaveTheNest',['../class_board.html#ad12c2609595eef4ad3ac43856c44d690',1,'Board']]],
  ['posclicked_303',['posClicked',['../class_board_widget.html#abac52eedbb79240ab01861a826996583',1,'BoardWidget']]]
];
