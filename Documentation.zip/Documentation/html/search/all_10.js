var searchData=
[
  ['tempstate_185',['tempState',['../class_board.html#ab2cc56e3cf557d6892ec9d54d4ed97be',1,'Board']]],
  ['terminatespot_186',['terminateSpot',['../class_board_position.html#a1122846016be4c355d21985f66af5e46',1,'BoardPosition']]],
  ['test_187',['TEST',['../_alec___google_tests___scratch_8txt.html#ad531ec8ebe8b7a1143cfac44b9b1b3f7',1,'TEST(PlayerTest, StartingPiecesTest):&#160;Alec_GoogleTests_Scratch.txt'],['../_alec___google_tests___scratch_8txt.html#a5d0f1baaef7d2da8e33180866f27e2a3',1,'TEST(PlayerTest, timeToFlyUnitTest):&#160;Alec_GoogleTests_Scratch.txt'],['../_alec___google_tests___scratch_8txt.html#a24b9bf6ebd5dd3a356f3eae5a2770b8d',1,'TEST(PlayerTest, subtractingPiecesTest):&#160;Alec_GoogleTests_Scratch.txt']]],
  ['test_5fcase_188',['TEST_CASE',['../unittest_8cpp.html#a68d1207bf7a4e70243b275b6d1b29433',1,'TEST_CASE(&quot;Player Class Tests&quot;,&quot;[player]&quot;):&#160;unittest.cpp'],['../unittest_8cpp.html#aad472ceb19b02ad31eff3ef7a240e242',1,'TEST_CASE(&quot;Board Class Tests&quot;, &quot;[board]&quot;):&#160;unittest.cpp'],['../unittest_8cpp.html#a28b1244eb11ce49a31f9801c3612b217',1,'TEST_CASE(&quot;Board Position Class Tests&quot;, &quot;[boardLocation&quot;):&#160;unittest.cpp'],['../unittest_8cpp.html#ac99b677487a814866bb4c8cd708838f6',1,'TEST_CASE(&quot;Tools to help Play the Game&quot;, &quot;[choicesDialog]&quot;):&#160;unittest.cpp'],['../unittest_8cpp.html#a9b01acc2b51e969b77199a353af61eb8',1,'TEST_CASE(&quot;AI Makin Moves&quot;, &quot;[aimoves]&quot;):&#160;unittest.cpp'],['../unittest_8cpp.html#abeba6a70e2e70aa04ea60ff774c44a32',1,'TEST_CASE(&quot;Giving up and resetting&quot;, &quot;[giveup]&quot;):&#160;unittest.cpp']]],
  ['thing_189',['thing',['../class_board_widget.html#a1ee839ac8287449cb09b079fbd79ebdf',1,'BoardWidget']]],
  ['timetofly_190',['timetoFly',['../class_player.html#a2d12d5b9a978905b23f9ab76d68e07f5',1,'Player']]],
  ['timetoflyunittest_191',['timeToFlyUnitTest',['../classmanual_tests.html#ada0bef321b3584c19ecc02d41c0b1dd9',1,'manualTests']]],
  ['togglephase2at_192',['togglePhase2At',['../class_board_widget.html#a65814a77bc6af659f25e7d319ff1487c',1,'BoardWidget']]],
  ['toggleplayer_193',['togglePlayer',['../class_board.html#a10693ac591332eeaeb17ecb364a4f941',1,'Board']]],
  ['twoplayerbutton_194',['twoplayerButton',['../classchoicesdialog.html#ad704b01db3c549b75f2a9dae986836e0',1,'choicesdialog']]]
];
