var searchData=
[
  ['offset_110',['offset',['../class_board_position.html#abfce24698d86787b9d7ba5928500109c',1,'BoardPosition']]]
];
