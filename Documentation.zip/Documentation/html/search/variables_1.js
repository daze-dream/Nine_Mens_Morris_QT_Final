var searchData=
[
  ['blank_348',['blank',['../class_board_widget.html#a7a1dd02c3e681f3eb9877ee4f2ca771c',1,'BoardWidget']]],
  ['board_349',['board',['../class_board.html#aa72c211d8bb2d94a98d307a1b06ec8f9',1,'Board']]],
  ['boardplayers_350',['BoardPlayers',['../class_board.html#a0c86058f44159e916d2445a55ccad2bf',1,'Board']]]
];
