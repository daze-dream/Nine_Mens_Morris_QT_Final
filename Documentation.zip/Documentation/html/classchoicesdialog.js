var classchoicesdialog =
[
    [ "choicesdialog", "classchoicesdialog.html#a44b31cfe685125e3f7026cbae3199f98", null ],
    [ "AIPressed", "classchoicesdialog.html#a4309af3f6de6c1e5730a5921a3754824", null ],
    [ "choiceMade", "classchoicesdialog.html#a245a1c9b0ae8f4b45a57718a7fc29b60", null ],
    [ "flipCoin", "classchoicesdialog.html#af8c63b1f5ea5f6780701f239adc01082", null ],
    [ "humanPressed", "classchoicesdialog.html#a3353b9594f913f82230a73c132e123bd", null ],
    [ "randomInteger", "classchoicesdialog.html#aed719fcb5a95d1531c9b540e2de67cc1", null ],
    [ "setMeUp", "classchoicesdialog.html#a3fb17efbd17e9165e6cc87a8137a4409", null ],
    [ "choiceDisplay", "classchoicesdialog.html#ab3776e83090e2b2b48404945d6425dd5", null ],
    [ "flipCoinButton", "classchoicesdialog.html#afd5b4797a932f3c67c17b9ce0acf1ac6", null ],
    [ "randNum", "classchoicesdialog.html#acca0f1eb8c7aa8c1fc60db8380c867f5", null ],
    [ "singleplayerButton", "classchoicesdialog.html#a6b07e8f51bd269f6e5eeb309a0371d78", null ],
    [ "twoplayerButton", "classchoicesdialog.html#ad704b01db3c549b75f2a9dae986836e0", null ]
];