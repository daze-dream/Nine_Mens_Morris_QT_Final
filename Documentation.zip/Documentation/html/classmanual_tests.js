var classmanual_tests =
[
    [ "manualTests", "classmanual_tests.html#ad8a7743c20afc502f8fcd027fcd1d67e", null ],
    [ "doAllTests", "classmanual_tests.html#a29d973147734f4cc12bce03874ae35c4", null ],
    [ "FlightMovementTest", "classmanual_tests.html#a4f82b0ac9a532406da2e592627b2402c", null ],
    [ "formMillTest", "classmanual_tests.html#a4ba3baad8f13035d8bc33a774e198ac9", null ],
    [ "moveValidityTest", "classmanual_tests.html#ac7f2804c39356bf16edc7c8324862530", null ],
    [ "subtractPieceUnitTest", "classmanual_tests.html#a50cdfd621d62dee80cd4049441c3327b", null ],
    [ "timeToFlyUnitTest", "classmanual_tests.html#ada0bef321b3584c19ecc02d41c0b1dd9", null ]
];