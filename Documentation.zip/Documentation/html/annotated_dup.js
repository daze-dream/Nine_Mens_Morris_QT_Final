var annotated_dup =
[
    [ "Board", "class_board.html", "class_board" ],
    [ "BoardLocation", "class_board_location.html", "class_board_location" ],
    [ "BoardPosition", "class_board_position.html", "class_board_position" ],
    [ "BoardPositionWidget", "class_board_position_widget.html", "class_board_position_widget" ],
    [ "BoardWidget", "class_board_widget.html", "class_board_widget" ],
    [ "choiceDialogTests", "classchoice_dialog_tests.html", "classchoice_dialog_tests" ],
    [ "choicesdialog", "classchoicesdialog.html", "classchoicesdialog" ],
    [ "MainWindow", "class_main_window.html", "class_main_window" ],
    [ "manualTests", "classmanual_tests.html", "classmanual_tests" ],
    [ "Player", "class_player.html", "class_player" ]
];