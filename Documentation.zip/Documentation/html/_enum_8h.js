var _enum_8h =
[
    [ "GameStates", "_enum_8h.html#ae3a29b920db0912c06cb59c2a21688ad", [
      [ "empty", "_enum_8h.html#ae3a29b920db0912c06cb59c2a21688adae8654263bd8adf1d0922f427d8f3fc1b", null ],
      [ "phase1", "_enum_8h.html#ae3a29b920db0912c06cb59c2a21688ada0e78824cb5bd532944d0cd6384ccfc42", null ],
      [ "phase2", "_enum_8h.html#ae3a29b920db0912c06cb59c2a21688adaf715ca0bd51ba8bb271f5e027c18ba9b", null ],
      [ "mill", "_enum_8h.html#ae3a29b920db0912c06cb59c2a21688ada73c288912bff3c53e158bff2113d74d3", null ],
      [ "gameOver", "_enum_8h.html#ae3a29b920db0912c06cb59c2a21688ada9481204dd1283f23698fca6d2b8b4160", null ]
    ] ]
];