var dir_b89c6037bfefa0e5d020a7058f32a811 =
[
    [ "Board.cpp", "_board_8cpp.html", null ],
    [ "Board.h", "_board_8h.html", [
      [ "Board", "class_board.html", "class_board" ]
    ] ],
    [ "BoardLocation.h", "_board_location_8h.html", [
      [ "BoardLocation", "class_board_location.html", "class_board_location" ]
    ] ],
    [ "BoardPosition.cpp", "_board_position_8cpp.html", null ],
    [ "BoardPosition.h", "_board_position_8h.html", [
      [ "BoardPosition", "class_board_position.html", "class_board_position" ]
    ] ],
    [ "boardpositionwidget.cpp", "boardpositionwidget_8cpp.html", null ],
    [ "boardpositionwidget.h", "boardpositionwidget_8h.html", [
      [ "BoardPositionWidget", "class_board_position_widget.html", "class_board_position_widget" ]
    ] ],
    [ "boardwidget.cpp", "boardwidget_8cpp.html", null ],
    [ "boardwidget.h", "boardwidget_8h.html", [
      [ "BoardWidget", "class_board_widget.html", "class_board_widget" ]
    ] ],
    [ "choicedialogtests.cpp", "choicedialogtests_8cpp.html", null ],
    [ "choicedialogtests.h", "choicedialogtests_8h.html", [
      [ "choiceDialogTests", "classchoice_dialog_tests.html", "classchoice_dialog_tests" ]
    ] ],
    [ "choicesdialog.cpp", "choicesdialog_8cpp.html", null ],
    [ "choicesdialog.h", "choicesdialog_8h.html", [
      [ "choicesdialog", "classchoicesdialog.html", "classchoicesdialog" ]
    ] ],
    [ "Enum.h", "_enum_8h.html", "_enum_8h" ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "mainwindow.cpp", "mainwindow_8cpp.html", null ],
    [ "mainwindow.h", "mainwindow_8h.html", [
      [ "MainWindow", "class_main_window.html", "class_main_window" ]
    ] ],
    [ "manualtests.cpp", "manualtests_8cpp.html", null ],
    [ "manualtests.h", "manualtests_8h.html", [
      [ "manualTests", "classmanual_tests.html", "classmanual_tests" ]
    ] ],
    [ "Player.cpp", "_player_8cpp.html", null ],
    [ "Player.h", "_player_8h.html", [
      [ "Player", "class_player.html", "class_player" ]
    ] ],
    [ "unittest.cpp", "unittest_8cpp.html", "unittest_8cpp" ]
];